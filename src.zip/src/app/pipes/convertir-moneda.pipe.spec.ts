import { ConvertirMonedaPipe } from './convertir-moneda.pipe';

describe('ConvertirMonedaPipe', () => {
  it('create an instance', () => {
    const pipe = new ConvertirMonedaPipe();
    expect(pipe).toBeTruthy();
  });
});
