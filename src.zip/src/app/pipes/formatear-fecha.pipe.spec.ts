import { FormatearFechaPipe } from './formatear-fecha.pipe';

describe('FormatearFechaPipe', () => {
  it('create an instance', () => {
    const pipe = new FormatearFechaPipe();
    expect(pipe).toBeTruthy();
  });
});
